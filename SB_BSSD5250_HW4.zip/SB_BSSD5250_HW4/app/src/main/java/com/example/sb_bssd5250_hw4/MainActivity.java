package com.example.sb_bssd5250_hw4;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);

        // outer layout - LinearLayout
        LinearLayout outerLayout = new LinearLayout( this);
        outerLayout.setBackgroundColor(Color.BLUE);
        outerLayout.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams outParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT,
                1.0f);
        outerLayout.setLayoutParams(outParams);

        // inner layout - TableLayout
        TableLayout tableLayout = new TableLayout(this);
        tableLayout.setBackgroundColor(Color.BLUE);
        TableLayout.LayoutParams tlParams = new TableLayout.LayoutParams(
                TableLayout.LayoutParams.WRAP_CONTENT,
                TableLayout.LayoutParams.WRAP_CONTENT);
        tableLayout.setLayoutParams(tlParams);

        // set up the table rows
        TableRow tr1 = makeTR();
        tr1.addView(makeIM(R.drawable.red));
        tr1.addView(makeIM(R.drawable.green));
        tr1.addView(makeIM(R.drawable.red));
        tr1.addView(makeIM(R.drawable.green));
        tr1.addView(makeIM(R.drawable.red));
        tr1.addView(makeIM(R.drawable.green));
        tr1.addView(makeIM(R.drawable.red));
        tr1.addView(makeIM(R.drawable.green));

        TableRow tr2 = makeTR();
        tr2.addView(makeIM(R.drawable.green_square));
        tr2.addView(makeIM(R.drawable.red_square));
        tr2.addView(makeIM(R.drawable.green_square));
        tr2.addView(makeIM(R.drawable.red_square));
        tr2.addView(makeIM(R.drawable.green_square));
        tr2.addView(makeIM(R.drawable.red_square));
        tr2.addView(makeIM(R.drawable.green_square));
        tr2.addView(makeIM(R.drawable.red_square));

        TableRow tr3 = makeTR();
        tr3.addView(makeIM(R.drawable.red_triangle_down));
        tr3.addView(makeIM(R.drawable.green_triangle_down));
        tr3.addView(makeIM(R.drawable.red_triangle_down));
        tr3.addView(makeIM(R.drawable.green_triangle_down));
        tr3.addView(makeIM(R.drawable.red_triangle_down));
        tr3.addView(makeIM(R.drawable.green_triangle_down));
        tr3.addView(makeIM(R.drawable.red_triangle_down));
        tr3.addView(makeIM(R.drawable.green_triangle_down));

        TableRow tr4 = makeTR();
        tr4.addView(makeIM(R.drawable.green_triangle_up));
        tr4.addView(makeIM(R.drawable.red_triangle_up));
        tr4.addView(makeIM(R.drawable.green_triangle_up));
        tr4.addView(makeIM(R.drawable.red_triangle_up));
        tr4.addView(makeIM(R.drawable.green_triangle_up));
        tr4.addView(makeIM(R.drawable.red_triangle_up));
        tr4.addView(makeIM(R.drawable.green_triangle_up));
        tr4.addView(makeIM(R.drawable.red_triangle_up));

        TableRow tr5 = makeTR();
        tr5.addView(makeIM(R.drawable.red_square));
        tr5.addView(makeIM(R.drawable.green_square));
        tr5.addView(makeIM(R.drawable.red_square));
        tr5.addView(makeIM(R.drawable.green_square));
        tr5.addView(makeIM(R.drawable.red_square));
        tr5.addView(makeIM(R.drawable.green_square));
        tr5.addView(makeIM(R.drawable.red_square));
        tr5.addView(makeIM(R.drawable.green_square));

        TableRow tr6 = makeTR();
        tr6.addView(makeIM(R.drawable.green));
        tr6.addView(makeIM(R.drawable.red));
        tr6.addView(makeIM(R.drawable.green));
        tr6.addView(makeIM(R.drawable.red));
        tr6.addView(makeIM(R.drawable.green));
        tr6.addView(makeIM(R.drawable.red));
        tr6.addView(makeIM(R.drawable.green));
        tr6.addView(makeIM(R.drawable.red));


        // attach all layouts
        tableLayout.addView(tr1);
        tableLayout.addView(tr2);
        tableLayout.addView(tr3);
        tableLayout.addView(tr4);
        tableLayout.addView(tr5);
        tableLayout.addView(tr6);
        outerLayout.addView(tableLayout);

        // show the final view
        setContentView(outerLayout);

    }

    private TableRow makeTR() {
        TableRow tableRow = new TableRow( this);
        tableRow.setBackgroundColor(Color.BLUE);
        TableRow.LayoutParams trParams = new TableRow.LayoutParams(
                TableRow.LayoutParams.WRAP_CONTENT,
                TableRow.LayoutParams.WRAP_CONTENT);
        tableRow.setLayoutParams(trParams);
        return  tableRow;

    }

    private ImageView makeIM(int resId) {
        ImageView imageView = new ImageView( this);
        imageView.setImageResource(resId);
        TableRow.LayoutParams imParams = new TableRow.LayoutParams(75,75);
        imageView.setLayoutParams(imParams);

        return  imageView;

    }


}
